﻿/*
 * Auteur  : nicolas.pschd
 * Nom de l'application : TestSQL
 * Description : Application de test pour les requêtes SQL en C#
 * Date : 13 Septembre 2016
 * Version : 1.0
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace TestSQL
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        static string infoDBCO = "server=127.0.0.1;user=root;database=tpg_db;password=;";
        MySqlConnection connectionDB = new MySqlConnection(infoDBCO);
        MySqlCommand cmd;

        private void frmMain_Load(object sender, EventArgs e)
        {
            //  Préparation de la requête de Select
            string requette = "SELECT * FROM t_tpg";
            cmd = new MySqlCommand(requette, connectionDB);

            try
            {
                connectionDB.Open();
                //  Lecture des données de la DB
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    //  Affiche les informations de la base de données dans la textBox
                    tbxDB.Text += reader.GetValue(0) + " " + reader.GetValue(1) + " " + reader.GetValue(2) + " " + reader.GetValue(3) + " " + reader.GetValue(4) + Environment.NewLine;
                }

                connectionDB.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur, veuille réessayer" + Environment.NewLine + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                connectionDB.Close();
            }
        }

        private void btnInsertLigne_Click(object sender, EventArgs e)
        {
            //  Préparation de la requête d'Insert
            string requette = "INSERT INTO t_tpg(noLigne,type,debut,fin) VALUES(@noLigne,@type,@debut,@fin)";
            cmd = new MySqlCommand(requette, connectionDB);

            //  Ajout des paramètres
            cmd.Parameters.AddWithValue("@noLigne", tbxInsertLigne.Text);
            cmd.Parameters.AddWithValue("@type", tbxInsertType.Text);
            cmd.Parameters.AddWithValue("@debut", tbxInsertDebut.Text);
            cmd.Parameters.AddWithValue("@fin", tbxInsertFin.Text);

            try
            {
                connectionDB.Open();

                //  Test si la requête s'est bien executée
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Succes", "Insert", MessageBoxButtons.OK);
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erreur, veuillez réessayer" + Environment.NewLine + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            connectionDB.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //  Préparation de la requête d'Update
            string requette = "UPDATE t_tpg SET noLigne=@noLigne, type=@type,debut=@debut,fin=@fin WHERE id=@id";
            cmd = new MySqlCommand(requette, connectionDB);

            //  Ajout des paramètres
            cmd.Parameters.AddWithValue("@noLigne", tbxUpdateLigne.Text);
            cmd.Parameters.AddWithValue("@type", tbxUpdateType.Text);
            cmd.Parameters.AddWithValue("@debut", tbxUpdateDebut.Text);
            cmd.Parameters.AddWithValue("@fin", tbxUpdateFin.Text);
            cmd.Parameters.AddWithValue("@id", tbxUpdateId.Text);

            try
            {
                connectionDB.Open();

                //  Test si la requête s'est bien executée
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Succes", "Update", MessageBoxButtons.OK);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur, veuille réessayer" + Environment.NewLine + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            connectionDB.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //  Préparation de la requête Delete
            string requette = "DELETE FROM t_tpg WHERE noLigne=@noLigne";
            cmd = new MySqlCommand(requette, connectionDB);

            //  Ajout du paramètre
            cmd.Parameters.AddWithValue("@noLigne", Convert.ToInt32(tbxDeleteNoLigne.Text));

            try
            {
                connectionDB.Open();

                //  Test si la requête s'est bien executée
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Succes", "Delete", MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur, veuille réessayer" + Environment.NewLine + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            connectionDB.Close();
        }
    }
}