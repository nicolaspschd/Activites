﻿namespace TestSQL
{
    partial class frmMain
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxDB = new System.Windows.Forms.TextBox();
            this.tbxUpdateLigne = new System.Windows.Forms.TextBox();
            this.btnInsertLigne = new System.Windows.Forms.Button();
            this.tbxUpdateType = new System.Windows.Forms.TextBox();
            this.tbxUpdateDebut = new System.Windows.Forms.TextBox();
            this.tbxUpdateFin = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.tbxUpdateId = new System.Windows.Forms.TextBox();
            this.gbxUpdate = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbxInsertFin = new System.Windows.Forms.TextBox();
            this.tbxInsertDebut = new System.Windows.Forms.TextBox();
            this.tbxInsertType = new System.Windows.Forms.TextBox();
            this.tbxInsertLigne = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.tbxDeleteNoLigne = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.gbxUpdate.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbxDB
            // 
            this.tbxDB.Location = new System.Drawing.Point(12, 12);
            this.tbxDB.Multiline = true;
            this.tbxDB.Name = "tbxDB";
            this.tbxDB.ReadOnly = true;
            this.tbxDB.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbxDB.Size = new System.Drawing.Size(260, 152);
            this.tbxDB.TabIndex = 0;
            // 
            // tbxUpdateLigne
            // 
            this.tbxUpdateLigne.Location = new System.Drawing.Point(97, 57);
            this.tbxUpdateLigne.Name = "tbxUpdateLigne";
            this.tbxUpdateLigne.Size = new System.Drawing.Size(157, 20);
            this.tbxUpdateLigne.TabIndex = 1;
            // 
            // btnInsertLigne
            // 
            this.btnInsertLigne.Location = new System.Drawing.Point(9, 117);
            this.btnInsertLigne.Name = "btnInsertLigne";
            this.btnInsertLigne.Size = new System.Drawing.Size(248, 22);
            this.btnInsertLigne.TabIndex = 2;
            this.btnInsertLigne.Text = "Insert";
            this.btnInsertLigne.UseVisualStyleBackColor = true;
            this.btnInsertLigne.Click += new System.EventHandler(this.btnInsertLigne_Click);
            // 
            // tbxUpdateType
            // 
            this.tbxUpdateType.Location = new System.Drawing.Point(97, 83);
            this.tbxUpdateType.Name = "tbxUpdateType";
            this.tbxUpdateType.Size = new System.Drawing.Size(157, 20);
            this.tbxUpdateType.TabIndex = 1;
            // 
            // tbxUpdateDebut
            // 
            this.tbxUpdateDebut.Location = new System.Drawing.Point(97, 109);
            this.tbxUpdateDebut.Name = "tbxUpdateDebut";
            this.tbxUpdateDebut.Size = new System.Drawing.Size(157, 20);
            this.tbxUpdateDebut.TabIndex = 1;
            // 
            // tbxUpdateFin
            // 
            this.tbxUpdateFin.Location = new System.Drawing.Point(97, 135);
            this.tbxUpdateFin.Name = "tbxUpdateFin";
            this.tbxUpdateFin.Size = new System.Drawing.Size(157, 20);
            this.tbxUpdateFin.TabIndex = 1;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(6, 161);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(248, 23);
            this.btnUpdate.TabIndex = 3;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // tbxUpdateId
            // 
            this.tbxUpdateId.Location = new System.Drawing.Point(97, 31);
            this.tbxUpdateId.Name = "tbxUpdateId";
            this.tbxUpdateId.Size = new System.Drawing.Size(157, 20);
            this.tbxUpdateId.TabIndex = 4;
            // 
            // gbxUpdate
            // 
            this.gbxUpdate.Controls.Add(this.label5);
            this.gbxUpdate.Controls.Add(this.label4);
            this.gbxUpdate.Controls.Add(this.label3);
            this.gbxUpdate.Controls.Add(this.label2);
            this.gbxUpdate.Controls.Add(this.label1);
            this.gbxUpdate.Controls.Add(this.tbxUpdateId);
            this.gbxUpdate.Controls.Add(this.btnUpdate);
            this.gbxUpdate.Controls.Add(this.tbxUpdateLigne);
            this.gbxUpdate.Controls.Add(this.tbxUpdateType);
            this.gbxUpdate.Controls.Add(this.tbxUpdateDebut);
            this.gbxUpdate.Controls.Add(this.tbxUpdateFin);
            this.gbxUpdate.Location = new System.Drawing.Point(12, 170);
            this.gbxUpdate.Name = "gbxUpdate";
            this.gbxUpdate.Size = new System.Drawing.Size(260, 194);
            this.gbxUpdate.TabIndex = 5;
            this.gbxUpdate.TabStop = false;
            this.gbxUpdate.Text = "Update";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "noLigne";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Type de bus";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Debut";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Fin";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.btnInsertLigne);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbxInsertFin);
            this.groupBox1.Controls.Add(this.tbxInsertDebut);
            this.groupBox1.Controls.Add(this.tbxInsertType);
            this.groupBox1.Controls.Add(this.tbxInsertLigne);
            this.groupBox1.Location = new System.Drawing.Point(278, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(260, 152);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Update";
            // 
            // tbxInsertFin
            // 
            this.tbxInsertFin.Location = new System.Drawing.Point(97, 91);
            this.tbxInsertFin.Name = "tbxInsertFin";
            this.tbxInsertFin.Size = new System.Drawing.Size(157, 20);
            this.tbxInsertFin.TabIndex = 1;
            // 
            // tbxInsertDebut
            // 
            this.tbxInsertDebut.Location = new System.Drawing.Point(97, 65);
            this.tbxInsertDebut.Name = "tbxInsertDebut";
            this.tbxInsertDebut.Size = new System.Drawing.Size(157, 20);
            this.tbxInsertDebut.TabIndex = 1;
            // 
            // tbxInsertType
            // 
            this.tbxInsertType.Location = new System.Drawing.Point(97, 39);
            this.tbxInsertType.Name = "tbxInsertType";
            this.tbxInsertType.Size = new System.Drawing.Size(157, 20);
            this.tbxInsertType.TabIndex = 1;
            // 
            // tbxInsertLigne
            // 
            this.tbxInsertLigne.Location = new System.Drawing.Point(97, 13);
            this.tbxInsertLigne.Name = "tbxInsertLigne";
            this.tbxInsertLigne.Size = new System.Drawing.Size(157, 20);
            this.tbxInsertLigne.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "noLigne";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Type de bus";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Debut";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 94);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Fin";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbxDeleteNoLigne);
            this.groupBox2.Controls.Add(this.btnDelete);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(278, 170);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(260, 195);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Delete";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(9, 161);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(245, 23);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // tbxDeleteNoLigne
            // 
            this.tbxDeleteNoLigne.Location = new System.Drawing.Point(97, 83);
            this.tbxDeleteNoLigne.Name = "tbxDeleteNoLigne";
            this.tbxDeleteNoLigne.Size = new System.Drawing.Size(157, 20);
            this.tbxDeleteNoLigne.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "noLigne";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 377);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbxUpdate);
            this.Controls.Add(this.tbxDB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "Test SQL";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.gbxUpdate.ResumeLayout(false);
            this.gbxUpdate.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxDB;
        private System.Windows.Forms.TextBox tbxUpdateLigne;
        private System.Windows.Forms.Button btnInsertLigne;
        private System.Windows.Forms.TextBox tbxUpdateType;
        private System.Windows.Forms.TextBox tbxUpdateDebut;
        private System.Windows.Forms.TextBox tbxUpdateFin;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox tbxUpdateId;
        private System.Windows.Forms.GroupBox gbxUpdate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbxInsertFin;
        private System.Windows.Forms.TextBox tbxInsertDebut;
        private System.Windows.Forms.TextBox tbxInsertType;
        private System.Windows.Forms.TextBox tbxInsertLigne;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbxDeleteNoLigne;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label10;
    }
}

