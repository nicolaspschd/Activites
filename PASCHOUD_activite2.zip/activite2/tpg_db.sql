-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mar 13 Septembre 2016 à 16:42
-- Version du serveur :  5.6.15-log
-- Version de PHP :  5.5.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `tpg_db`
--
CREATE DATABASE IF NOT EXISTS `tpg_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `tpg_db`;

-- --------------------------------------------------------

--
-- Structure de la table `t_tpg`
--

CREATE TABLE IF NOT EXISTS `t_tpg` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `noLigne` varchar(4) NOT NULL,
  `type` varchar(50) NOT NULL,
  `debut` varchar(60) NOT NULL,
  `fin` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=56 ;

--
-- Contenu de la table `t_tpg`
--

INSERT INTO `t_tpg` (`id`, `noLigne`, `type`, `debut`, `fin`) VALUES
(1, '12', 'Tramway', 'Palettes', 'Moillesulaz'),
(2, '14', 'Tramway', 'P+R Bernex', 'Meyrin-GraviÃ¨re ou CERN'),
(3, '15', 'Tramway', 'Palettes', 'Nations'),
(4, '1', 'AutoBus', 'Petit-Bel-Air', 'Jardin Botanique'),
(5, '2', 'TrolleyBus', 'GenÃ¨ve-Plage', 'Onex-CitÃ©'),
(6, '3', 'TrolleyBus', 'Gardiol', 'CrÃ©ts-de-Champel'),
(7, '4', 'AutoBus', 'Bel-Air', 'P+R Perly'),
(8, '5', 'AutoBus', 'ThÃ´nex-Vallard', 'AÃ©roport'),
(9, '6', 'TrolleyBus', 'Vernier-Village', 'GenÃ¨ve-Plage'),
(10, '7', 'TrolleyBus', 'HÃ´pital', 'Tours Lignon'),
(11, '8', 'AutoBus', 'OMS', 'Veyrier-Douane ou Veyrier-Tournettes'),
(12, '9', 'AutoBus', 'Petit-Bel-Air', 'Tours Lignon'),
(13, '10', 'TrolleyBus', 'AÃ©roport', 'Rive'),
(14, '11', 'AutoBus', 'Jardin Botanique', 'Bout-du-Monde'),
(15, '19', 'TrolleyBus', 'Vernier-Village', 'Onex-CitÃ©'),
(16, '21', 'AutoBus', 'Cressy', 'Gare Eaux-Vives'),
(17, '22', 'AutoBus', 'Nations', 'Tours-de-Carouge'),
(18, '23', 'AutoBus', 'AÃ©roport', 'ZIPLO'),
(19, '28', 'AutoBus', 'Jardin Botanique', 'Parfumerie'),
(20, '31', 'AutoBus', 'P+R Sous-Moulin', 'Puplinge-Marquis'),
(21, '33', 'AutoBus', 'Rive', 'Chevrier'),
(22, '34', 'AutoBus', 'Veyrier-Tournettes', 'Chevrier'),
(23, '35', 'AutoBus', 'Augustins', 'Augustins'),
(24, '36', 'AutoBus', 'Place Neuve', 'Place Neuve'),
(25, '41', 'AutoBus', 'Tours-de-Carouge', 'Petit-Veyrier'),
(26, '42', 'AutoBus', 'Carouge', 'CroisÃ©e de Confignon'),
(27, '43', 'AutoBus', 'Stade de GenÃ¨ve', 'LoÃªx-HÃ´pital'),
(28, '44', 'AutoBus', 'Tours-de-Carouge', 'Croix-de-Rozon-Douane'),
(29, '45', 'AutoBus', 'Tours-de-Carouge', 'Troinex-Ville'),
(30, '46', 'AutoBus', 'Bellins', 'Bardonnex'),
(31, '47', 'AutoBus', 'CroisÃ©e de Confignon', 'Bernex-Saule'),
(32, '51', 'AutoBus', 'C.O. Renard', 'Mervelet'),
(33, '53', 'AutoBus', 'Bouchet', 'MachÃ©ry'),
(34, '54', 'AutoBus', 'Satigny-Gare', 'Gare ZIMEYSA'),
(35, '57', 'AutoBus', 'AÃ©roport', 'Gare de Meyrin'),
(36, 'a', 'AutoBus', 'Rive', 'Gy-Eglise-Corsinge-Village'),
(37, 'b', 'AutoBus', 'VÃ©senaz-Eglise', 'Chevrens'),
(38, 'c', 'AutoBus', 'Malagnou/P+R Sous-Moulin', 'Jussy-Meurets/Monniaz'),
(39, 'd', 'AutoBus', 'Bel-Air', 'Saint-Julien-Gare'),
(40, 'e', 'AutoBus', 'Rive', 'Hermance'),
(41, 'f', 'AutoBus', 'Gare Cornavin', 'Ferney-Mairie ou Gex-ZAC'),
(42, 'g', 'AutoBus', 'Rive', 'P+R Veigy/Veigy'),
(43, 'k', 'AutoBus', 'Petite-VendÃ©e', 'Pougny-Gare'),
(44, 'l', 'AutoBus', 'Petite-VendÃ©e', 'Avusy'),
(45, 'o', 'AutoBus', 'Meyrin-GraviÃ¨re', 'LycÃ©e International'),
(46, 's', 'AutoBus', 'SÃ¨zenove', 'Satigny-Gare'),
(47, 't', 'AutoBus', 'La Plaine', 'P+R Challex-La Halle'),
(48, 'v', 'AutoBus', 'Gare Cornavin', 'C.S. la BÃ©cassiÃ¨re'),
(49, 'w', 'AutoBus', 'Satigny-Gare', 'Satigny-Gare'),
(50, 'x', 'AutoBus', 'Chancy-Douane', 'Dardagny'),
(51, 'y', 'AutoBus', 'Ferney-Voltaire-Mairie', 'Val-Thoiry'),
(52, 'z', 'AutoBus', 'Gare Cornavin', 'Bossy ou Bois-Chatton');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
